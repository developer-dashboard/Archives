using Bridge;
using Bridge.Html5;

namespace Demo
{
	public class App
	{
		[Ready]
		public static void Main()
		{
			Global.Alert("Success!");
		}
	}
}